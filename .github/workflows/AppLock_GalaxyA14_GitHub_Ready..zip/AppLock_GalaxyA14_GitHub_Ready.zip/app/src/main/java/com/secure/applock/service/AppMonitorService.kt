package com.secure.applock.service

import android.app.Notification
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.secure.applock.AppLockApplication
import com.secure.applock.R
import com.secure.applock.data.AppLockPreferences
import com.secure.applock.ui.LockOverlayActivity

class AppMonitorService : Service() {

    private lateinit var prefs: AppLockPreferences
    private lateinit var usageStatsManager: UsageStatsManager
    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false

    private var lastForegroundPackage: String? = null

    companion object {
        // Map storing timestamp when an app was successfully unlocked
        val unlockedAppsTimestamps = mutableMapOf<String, Long>()
        var isCurrentlyShowingOverlay = false

        fun recordUnlock(packageName: String) {
            unlockedAppsTimestamps[packageName] = SystemClock.elapsedRealtime()
            isCurrentlyShowingOverlay = false
        }
    }

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                // If policy is screen_off, clear unlocked list so everything locks
                if (prefs.relockPolicy == "screen_off" || prefs.relockPolicy == "immediately") {
                    unlockedAppsTimestamps.clear()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = AppLockPreferences(this)
        usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
        startForeground(1001, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) {
            isRunning = true
            startMonitoringLoop()
        }
        return START_STICKY
    }

    private fun startMonitoringLoop() {
        handler.post(object : Runnable {
            override fun run() {
                checkForegroundApp()
                if (isRunning) {
                    handler.postDelayed(this, 350) // High-responsiveness check
                }
            }
        })
    }

    private fun checkForegroundApp() {
        val currentPkg = getTopPackageName() ?: return

        // Skip our own overlay to prevent recursion
        if (currentPkg == packageName && isCurrentlyShowingOverlay) return

        if (currentPkg != lastForegroundPackage) {
            // App switched
            if (prefs.relockPolicy == "immediately") {
                // Relock immediately on switch away
                if (lastForegroundPackage != null) {
                    unlockedAppsTimestamps.remove(lastForegroundPackage)
                }
            }
            lastForegroundPackage = currentPkg
        }

        // Check if currentPkg is locked
        val isTargetLocked = if (currentPkg == packageName) {
            prefs.isSelfLockEnabled
        } else {
            prefs.isPackageLocked(currentPkg)
        }

        if (isTargetLocked) {
            if (!isAppTemporarilyUnlocked(currentPkg) && !isCurrentlyShowingOverlay) {
                triggerLockOverlay(currentPkg)
            }
        }
    }

    private fun isAppTemporarilyUnlocked(pkg: String): Boolean {
        val unlockTime = unlockedAppsTimestamps[pkg] ?: return false
        val elapsed = SystemClock.elapsedRealtime() - unlockTime

        return when (prefs.relockPolicy) {
            "immediately" -> false
            "screen_off" -> true // Kept until screen turns off
            "1_min" -> elapsed < 60_000
            "5_min" -> elapsed < 300_000
            "custom" -> elapsed < (prefs.customTimeoutMinutes * 60_000L)
            else -> elapsed < 60_000
        }
    }

    private fun triggerLockOverlay(targetPackage: String) {
        isCurrentlyShowingOverlay = true
        val intent = Intent(this, LockOverlayActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            putExtra(LockOverlayActivity.EXTRA_TARGET_PACKAGE, targetPackage)
        }
        startActivity(intent)
    }

    private fun getTopPackageName(): String? {
        val endTime = System.currentTimeMillis()
        val beginTime = endTime - 1000 * 5
        val events = usageStatsManager.queryEvents(beginTime, endTime)
        val event = UsageEvents.Event()
        var lastPkg: String? = null

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                lastPkg = event.packageName
            }
        }
        return lastPkg
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, AppLockApplication.CHANNEL_ID)
            .setContentTitle("AppLock Pro Active")
            .setContentText("Protecting your private applications")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        try {
            unregisterReceiver(screenOffReceiver)
        } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
