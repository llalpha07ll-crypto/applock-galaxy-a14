package com.secure.applock.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

class AppLockPreferences(context: Context) {

    private val prefs: SharedPreferences

    init {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        prefs = EncryptedSharedPreferences.create(
            context,
            "secure_applock_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // Master PIN Storage (SHA-256 hashed)
    fun setMasterPin(pin: String) {
        val hash = hashPin(pin)
        prefs.edit().putString(KEY_MASTER_PIN, hash).apply()
    }

    fun isMasterPinSet(): Boolean {
        return prefs.contains(KEY_MASTER_PIN)
    }

    fun verifyPin(inputPin: String): Boolean {
        val storedHash = prefs.getString(KEY_MASTER_PIN, null) ?: return false
        return storedHash == hashPin(inputPin)
    }

    // Locked Apps Set
    fun getLockedPackages(): MutableSet<String> {
        return prefs.getStringSet(KEY_LOCKED_PACKAGES, mutableSetOf())?.toMutableSet() ?: mutableSetOf()
    }

    fun setLockedPackages(packages: Set<String>) {
        prefs.edit().putStringSet(KEY_LOCKED_PACKAGES, packages).apply()
    }

    fun isPackageLocked(pkg: String): Boolean {
        val locked = getLockedPackages()
        return locked.contains(pkg)
    }

    fun toggleAppLock(pkg: String, shouldLock: Boolean) {
        val set = getLockedPackages()
        if (shouldLock) {
            set.add(pkg)
        } else {
            set.remove(pkg)
        }
        setLockedPackages(set)
    }

    // Relock Timeout Policy
    // Options: "immediately", "screen_off", "1_min", "5_min", "custom"
    var relockPolicy: String
        get() = prefs.getString(KEY_RELOCK_POLICY, "screen_off") ?: "screen_off"
        set(value) = prefs.edit().putString(KEY_RELOCK_POLICY, value).apply()

    var customTimeoutMinutes: Int
        get() = prefs.getInt(KEY_CUSTOM_TIMEOUT_MIN, 5)
        set(value) = prefs.edit().putInt(KEY_CUSTOM_TIMEOUT_MIN, value).apply()

    // Self Lock (Protects AppLock Pro itself)
    var isSelfLockEnabled: Boolean
        get() = prefs.getBoolean(KEY_SELF_LOCK, true)
        set(value) = prefs.edit().putBoolean(KEY_SELF_LOCK, value).apply()

    // Biometrics toggle (Use system sensor prompt or pure PIN)
    var isBiometricEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRIC, true)
        set(value) = prefs.edit().putBoolean(KEY_BIOMETRIC, value).apply()

    private fun hashPin(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val KEY_MASTER_PIN = "key_master_pin_hash"
        private const val KEY_LOCKED_PACKAGES = "key_locked_packages"
        private const val KEY_RELOCK_POLICY = "key_relock_policy"
        private const val KEY_CUSTOM_TIMEOUT_MIN = "key_custom_timeout_min"
        private const val KEY_SELF_LOCK = "key_self_lock"
        private const val KEY_BIOMETRIC = "key_biometric"
    }
}
