package com.secure.applock.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.secure.applock.R
import com.secure.applock.data.AppLockPreferences
import com.secure.applock.databinding.ActivityLockOverlayBinding
import com.secure.applock.service.AppMonitorService
import java.util.concurrent.Executor

class LockOverlayActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLockOverlayBinding
    private lateinit var prefs: AppLockPreferences
    private var targetPackage: String? = null
    private var enteredPin = StringBuilder()

    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo

    companion object {
        const val EXTRA_TARGET_PACKAGE = "extra_target_package"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockOverlayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppLockPreferences(this)
        targetPackage = intent.getStringExtra(EXTRA_TARGET_PACKAGE) ?: packageName

        setupTargetAppIdentity()
        setupKeypadListeners()

        executor = ContextCompat.getMainExecutor(this)
        setupBiometricPrompt()

        if (prefs.isBiometricEnabled) {
            showBiometricStage()
        } else {
            showPinStage()
        }
    }

    private fun setupTargetAppIdentity() {
        val pkg = targetPackage ?: return
        try {
            val pm = packageManager
            val appInfo = pm.getApplicationInfo(pkg, 0)
            val appName = pm.getApplicationLabel(appInfo).toString()
            val appIcon: Drawable = pm.getApplicationIcon(appInfo)

            // Dynamic updates for Stage 1 (Biometric Screen)
            binding.bioTargetName.text = appName
            binding.bioTargetIcon.setImageDrawable(appIcon)
            binding.bioUnlockTitle.text = "Unlock $appName"
            binding.bioSubtext.text = "Confirm biometric authentication to access $appName"

            // Dynamic updates for Stage 2 (PIN Screen)
            binding.pinTargetName.text = appName
            binding.pinTargetIcon.setImageDrawable(appIcon)
            binding.pinSubtext.text = "Confirm biometric authentication to access $appName"

        } catch (e: PackageManager.NameNotFoundException) {
            binding.bioUnlockTitle.text = "Unlock Application"
        }
    }

    private fun setupBiometricPrompt() {
        biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    handleUnlockSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    // If biometric is cancelled or fails, fallback smoothly to PIN
                    showPinStage()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    Toast.makeText(this@LockOverlayActivity, "Biometric not recognized", Toast.LENGTH_SHORT).show()
                }
            })

        val appName = binding.bioTargetName.text.toString()
        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock $appName")
            .setSubtitle("Confirm biometric authentication to access $appName")
            .setNegativeButtonText("Use PIN")
            .build()
    }

    private fun showBiometricStage() {
        binding.oneuiBiometricStage.visibility = View.VISIBLE
        binding.oneuiPinStage.visibility = View.GONE

        binding.oneuiFingerprintCircle.setOnClickListener {
            biometricPrompt.authenticate(promptInfo)
        }
        binding.oneuiUsePinBtn.setOnClickListener {
            showPinStage()
        }
    }

    private fun showPinStage() {
        binding.oneuiBiometricStage.visibility = View.GONE
        binding.oneuiPinStage.visibility = View.VISIBLE
        enteredPin.clear()
        updatePinDots()
    }

    private fun setupKeypadListeners() {
        // Digit Buttons 0-9
        val numberMap = mapOf(
            binding.key1 to "1", binding.key2 to "2", binding.key3 to "3",
            binding.key4 to "4", binding.key5 to "5", binding.key6 to "6",
            binding.key7 to "7", binding.key8 to "8", binding.key9 to "9",
            binding.key0 to "0"
        )

        numberMap.forEach { (view, digit) ->
            view.setOnClickListener {
                if (enteredPin.length < 4) {
                    enteredPin.append(digit)
                    updatePinDots()
                    if (enteredPin.length == 4) {
                        Handler(Looper.getMainLooper()).postDelayed({ verifyEnteredPin() }, 150)
                    }
                }
            }
        }

        binding.keyBackspace.setOnClickListener {
            if (enteredPin.isNotEmpty()) {
                enteredPin.deleteCharAt(enteredPin.length - 1)
                updatePinDots()
            }
        }

        binding.keyDone.setOnClickListener {
            verifyEnteredPin()
        }

        binding.btnCancelPin.setOnClickListener {
            goToHomeScreen()
        }

        binding.btnContinuePin.setOnClickListener {
            verifyEnteredPin()
        }
    }

    private fun updatePinDots() {
        val len = enteredPin.length
        binding.dot0.isSelected = len > 0
        binding.dot1.isSelected = len > 1
        binding.dot2.isSelected = len > 2
        binding.dot3.isSelected = len > 3
    }

    private fun verifyEnteredPin() {
        val pin = enteredPin.toString()
        if (prefs.verifyPin(pin)) {
            handleUnlockSuccess()
        } else {
            // Shake animation on incorrect PIN
            val shake = AnimationUtils.loadAnimation(this, R.anim.shake)
            binding.pinInputWrapper.startAnimation(shake)
            Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
            enteredPin.clear()
            updatePinDots()
        }
    }

    private fun handleUnlockSuccess() {
        targetPackage?.let { pkg ->
            AppMonitorService.recordUnlock(pkg)
        }
        finish()
        overridePendingTransition(0, 0)
    }

    private fun goToHomeScreen() {
        AppMonitorService.isCurrentlyShowingOverlay = false
        val startMain = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(startMain)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Prevent bypassing the lock overlay via back button
        goToHomeScreen()
    }
}
