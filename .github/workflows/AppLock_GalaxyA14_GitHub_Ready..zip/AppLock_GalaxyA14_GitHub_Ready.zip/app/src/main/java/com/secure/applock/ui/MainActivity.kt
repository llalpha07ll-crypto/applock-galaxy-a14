package com.secure.applock.ui

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.textfield.TextInputEditText
import com.secure.applock.R
import com.secure.applock.data.AppLockPreferences
import com.secure.applock.databinding.ActivityMainBinding
import com.secure.applock.service.AppMonitorService
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppLockPreferences
    private lateinit var adapter: AppListAdapter
    private val allApps = mutableListOf<AppItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppLockPreferences(this)

        // Ensure Master PIN is initialized
        if (!prefs.isMasterPinSet()) {
            showInitialPinSetupDialog()
        }

        checkAndRequestPermissions()
        setupUI()
        setupBottomNavigation()
        loadInstalledApps()
        startMonitorService()
    }

    private fun setupUI() {
        // RecyclerView Setup
        adapter = AppListAdapter { app, isLocked ->
            prefs.toggleAppLock(app.packageName, isLocked)
            updateLockCounts()
        }
        binding.rvApps.layoutManager = LinearLayoutManager(this)
        binding.rvApps.adapter = adapter

        // Search Box Listener
        binding.etSearchApps.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterApps(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Master "Lock All / Unlock All" Toggle Button
        binding.btnLockAll.setOnClickListener {
            val allLocked = allApps.all { it.isLocked }
            val newState = !allLocked
            allApps.forEach {
                it.isLocked = newState
                prefs.toggleAppLock(it.packageName, newState)
            }
            adapter.submitList(allApps.toList())
            updateLockCounts()
            Toast.makeText(this, if (newState) "All apps locked" else "All apps unlocked", Toast.LENGTH_SHORT).show()
        }

        // Security & Relock Setup
        setupSecurityTab()
    }

    private fun setupSecurityTab() {
        val policies = listOf("immediately", "screen_off", "1_min", "5_min", "custom")
        val displayPolicies = listOf("Immediately", "When Screen Turns Off", "After 1 Minute", "After 5 Minutes", "Custom (15 min)")
        
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, displayPolicies)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerRelockPolicy.adapter = spinnerAdapter
        
        val currentIndex = policies.indexOf(prefs.relockPolicy).coerceAtLeast(1)
        binding.spinnerRelockPolicy.setSelection(currentIndex)

        binding.switchSelfLock.isChecked = prefs.isSelfLockEnabled
        binding.switchSelfLock.setOnCheckedChangeListener { _, isChecked ->
            prefs.isSelfLockEnabled = isChecked
        }

        binding.switchBiometric.isChecked = prefs.isBiometricEnabled
        binding.switchBiometric.setOnCheckedChangeListener { _, isChecked ->
            prefs.isBiometricEnabled = isChecked
        }

        binding.btnChangePin.setOnClickListener {
            showChangePinDialog()
        }
    }

    private fun setupBottomNavigation() {
        binding.bottomNavBar.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_management -> {
                    binding.layoutManagementTab.visibility = View.VISIBLE
                    binding.layoutSecurityTab.visibility = View.GONE
                    binding.layoutSettingsTab.visibility = View.GONE
                    true
                }
                R.id.nav_security -> {
                    binding.layoutManagementTab.visibility = View.GONE
                    binding.layoutSecurityTab.visibility = View.VISIBLE
                    binding.layoutSettingsTab.visibility = View.GONE
                    true
                }
                R.id.nav_settings -> {
                    binding.layoutManagementTab.visibility = View.GONE
                    binding.layoutSecurityTab.visibility = View.GONE
                    binding.layoutSettingsTab.visibility = View.VISIBLE
                    true
                }
                else -> false
            }
        }
    }

    private fun loadInstalledApps() {
        val pm = packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        allApps.clear()

        val lockedSet = prefs.getLockedPackages()

        for (app in packages) {
            // Filter out system apps without launcher intent
            val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
            if (launchIntent != null && app.packageName != packageName) {
                val name = pm.getApplicationLabel(app).toString()
                val icon = pm.getApplicationIcon(app)
                val isLocked = lockedSet.contains(app.packageName)
                allApps.add(AppItem(name, app.packageName, icon, isLocked))
            }
        }

        allApps.sortBy { it.name.lowercase(Locale.ROOT) }
        adapter.submitList(allApps.toList())
        updateLockCounts()
    }

    private fun filterApps(query: String) {
        val filtered = allApps.filter {
            it.name.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true)
        }
        adapter.submitList(filtered)
    }

    private fun updateLockCounts() {
        val lockedCount = allApps.count { it.isLocked }
        binding.tvLockedCount.text = lockedCount.toString()
        binding.tvUnlockedCount.text = (allApps.size - lockedCount).toString()
        binding.btnLockAll.text = if (lockedCount == allApps.size) "Unlock All" else "Lock All"
    }

    private fun showInitialPinSetupDialog() {
        val input = TextInputEditText(this)
        input.hint = "4-digit PIN (e.g. 1234)"
        AlertDialog.Builder(this)
            .setTitle("Create Master PIN")
            .setMessage("Set your private AppLock PIN. This is independent of your Samsung lock screen.")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Set PIN") { _, _ ->
                val pin = input.text.toString().trim()
                if (pin.length == 4 && pin.all { it.isDigit() }) {
                    prefs.setMasterPin(pin)
                    Toast.makeText(this, "Master PIN created successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Please enter 4 digits", Toast.LENGTH_SHORT).show()
                    showInitialPinSetupDialog()
                }
            }
            .show()
    }

    private fun showChangePinDialog() {
        val input = TextInputEditText(this)
        input.hint = "New 4-digit PIN"
        AlertDialog.Builder(this)
            .setTitle("Change Master PIN")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val pin = input.text.toString().trim()
                if (pin.length == 4 && pin.all { it.isDigit() }) {
                    prefs.setMasterPin(pin)
                    Toast.makeText(this, "PIN updated successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "PIN must be 4 digits", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun checkAndRequestPermissions() {
        if (!hasUsageStatsPermission()) {
            Toast.makeText(this, "Please grant Usage Access for app detection", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant Appear on Top permission", Toast.LENGTH_LONG).show()
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
        }
    }

    private fun hasUsageStatsPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        } else {
            appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun startMonitorService() {
        val intent = Intent(this, AppMonitorService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}
