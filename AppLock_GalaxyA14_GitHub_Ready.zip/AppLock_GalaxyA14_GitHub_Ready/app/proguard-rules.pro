# Proguard rules
-keep class com.secure.applock.** { *; }
