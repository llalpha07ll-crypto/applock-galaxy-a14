package com.secure.applock.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.sqrt

class PatternLockView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 14f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.parseColor("#0A58CA")
    }

    private val selectedDots = mutableListOf<Int>()
    private var currentX = 0f
    private var currentY = 0f
    private var isDrawing = false
    private var onPatternListener: ((String) -> Unit)? = null

    private val dotCoords = Array(9) { FloatArray(2) }

    fun setOnPatternListener(listener: (String) -> Unit) {
        onPatternListener = listener
    }

    fun clearPattern() {
        selectedDots.clear()
        isDrawing = false
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cellW = w / 3f
        val cellH = h / 3f
        for (i in 0 until 9) {
            val col = i % 3
            val row = i / 3
            dotCoords[i][0] = col * cellW + cellW / 2f
            dotCoords[i][1] = row * cellH + cellH / 2f
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Draw Lines between selected dots
        if (selectedDots.isNotEmpty()) {
            val path = Path()
            val first = selectedDots[0]
            path.moveTo(dotCoords[first][0], dotCoords[first][1])
            for (idx in 1 until selectedDots.size) {
                val dot = selectedDots[idx]
                path.lineTo(dotCoords[dot][0], dotCoords[dot][1])
            }
            if (isDrawing) {
                path.lineTo(currentX, currentY)
            }
            canvas.drawPath(path, linePaint)
        }

        // Draw 3x3 Dots
        for (i in 0 until 9) {
            val x = dotCoords[i][0]
            val y = dotCoords[i][1]
            if (selectedDots.contains(i)) {
                dotPaint.color = Color.parseColor("#0A58CA")
                canvas.drawCircle(x, y, 22f, dotPaint)
                dotPaint.color = Color.parseColor("#4D0A58CA")
                canvas.drawCircle(x, y, 38f, dotPaint)
            } else {
                dotPaint.color = Color.parseColor("#A0B0C0")
                canvas.drawCircle(x, y, 14f, dotPaint)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                selectedDots.clear()
                isDrawing = true
                checkDotHit(event.x, event.y)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                currentX = event.x
                currentY = event.y
                checkDotHit(event.x, event.y)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDrawing = false
                invalidate()
                if (selectedDots.isNotEmpty()) {
                    val patternString = selectedDots.joinToString("-")
                    onPatternListener?.invoke(patternString)
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun checkDotHit(x: Float, y: Float) {
        val radiusThreshold = 75f
        for (i in 0 until 9) {
            if (!selectedDots.contains(i)) {
                val dx = x - dotCoords[i][0]
                val dy = y - dotCoords[i][1]
                val dist = sqrt(dx * dx + dy * dy)
                if (dist <= radiusThreshold) {
                    selectedDots.add(i)
                    break
                }
            }
        }
    }
}
