package com.secure.applock.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.sqrt

class PatternLockView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // Samsung One UI Colors
    private val normalDotColor = Color.parseColor("#B0C0D0")
    private val activeBlue = Color.parseColor("#2D7FF9")
    private val errorRed = Color.parseColor("#FF3B30")
    private val outerRingBlue = Color.parseColor("#332D7FF9")
    private val outerRingRed = Color.parseColor("#33FF3B30")

    private var isErrorState = false

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 14f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val selectedDots = mutableListOf<Int>()
    private var currentX = 0f
    private var currentY = 0f
    private var isDrawing = false
    private var onPatternListener: ((String) -> Unit)? = null
    private val dotCoords = Array(9) { FloatArray(2) }

    private val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    fun setOnPatternListener(listener: (String) -> Unit) {
        onPatternListener = listener
    }

    fun setErrorState() {
        isErrorState = true
        vibratePhone()
        invalidate()
    }

    fun clearPattern() {
        selectedDots.clear()
        isDrawing = false
        isErrorState = false
        invalidate()
    }

    private fun vibratePhone() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                vibrator?.vibrate(45)
            }
        } catch (_: Exception) {}
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val padding = 40f
        val availableW = w - padding * 2
        val availableH = h - padding * 2
        val cellW = availableW / 2f
        val cellH = availableH / 2f

        for (i in 0 until 9) {
            val col = i % 3
            val row = i / 3
            dotCoords[i][0] = padding + col * cellW
            dotCoords[i][1] = padding + row * cellH
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val currentColor = if (isErrorState) errorRed else activeBlue
        val currentRingColor = if (isErrorState) outerRingRed else outerRingBlue
        linePaint.color = currentColor

        // 1. Draw One UI Connecting Path
        if (selectedDots.isNotEmpty()) {
            val path = Path()
            val first = selectedDots[0]
            path.moveTo(dotCoords[first][0], dotCoords[first][1])
            for (idx in 1 until selectedDots.size) {
                val dot = selectedDots[idx]
                path.lineTo(dotCoords[dot][0], dotCoords[dot][1])
            }
            if (isDrawing && !isErrorState) {
                path.lineTo(currentX, currentY)
            }
            canvas.drawPath(path, linePaint)
        }

        // 2. Draw 3x3 Dots with Samsung One UI Outer Halo
        for (i in 0 until 9) {
            val x = dotCoords[i][0]
            val y = dotCoords[i][1]

            if (selectedDots.contains(i)) {
                // Outer subtle expansion ring
                ringPaint.color = currentRingColor
                canvas.drawCircle(x, y, 42f, ringPaint)

                // Inner bold dot
                dotPaint.color = currentColor
                canvas.drawCircle(x, y, 18f, dotPaint)
            } else {
                // Inactive subtle dot
                dotPaint.color = normalDotColor
                canvas.drawCircle(x, y, 12f, dotPaint)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                clearPattern()
                isDrawing = true
                checkDotHit(event.x, event.y)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!isErrorState) {
                    currentX = event.x
                    currentY = event.y
                    checkDotHit(event.x, event.y)
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isDrawing = false
                invalidate()
                if (selectedDots.isNotEmpty()) {
                    val patternString = selectedDots.joinToString("-")
                    onPatternListener?.invoke(patternString)
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun checkDotHit(x: Float, y: Float) {
        val radiusThreshold = 80f
        for (i in 0 until 9) {
            if (!selectedDots.contains(i)) {
                val dx = x - dotCoords[i][0]
                val dy = y - dotCoords[i][1]
                val dist = sqrt(dx * dx + dy * dy)
                if (dist <= radiusThreshold) {
                    selectedDots.add(i)
                    vibratePhone()
                    break
                }
            }
        }
    }
}
