package com.secure.applock.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.secure.applock.R
import com.secure.applock.data.AppLockPreferences
import com.secure.applock.databinding.ActivityLockOverlayBinding
import com.secure.applock.service.AppLockAccessibilityService
import java.util.concurrent.Executor

class LockOverlayActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLockOverlayBinding
    private lateinit var prefs: AppLockPreferences
    private var targetPackage: String? = null
    private var enteredPin = StringBuilder()
    private var targetAppName = "Application"

    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo

    companion object {
        const val EXTRA_TARGET_PACKAGE = "extra_target_package"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockOverlayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefs = AppLockPreferences(this)
        targetPackage = intent.getStringExtra(EXTRA_TARGET_PACKAGE) ?: packageName

        setupTargetAppIdentity()

        if (prefs.lockType == "PATTERN") {
            setupPatternLockView()
        } else {
            setupPinLockView()
        }

        // Direct Biometrics over the Lock Screen
        if (prefs.isBiometricEnabled) {
            setupBiometricPrompt()
            Handler(Looper.getMainLooper()).postDelayed({
                try {
                    biometricPrompt.authenticate(promptInfo)
                } catch (_: Exception) {}
            }, 180)
        }
    }

    private fun setupTargetAppIdentity() {
        val pkg = targetPackage ?: return
        try {
            val pm = packageManager
            val appInfo = pm.getApplicationInfo(pkg, 0)
            targetAppName = pm.getApplicationLabel(appInfo).toString()
            val appIcon: Drawable = pm.getApplicationIcon(appInfo)

            binding.ivTargetAppIcon.setImageDrawable(appIcon)
            binding.tvTargetAppName.text = targetAppName
            binding.tvLockSubtitle.text = "Confirm authentication to access $targetAppName"
        } catch (e: PackageManager.NameNotFoundException) {
            binding.tvTargetAppName.text = targetAppName
        }
    }

    private fun setupPinLockView() {
        binding.layoutPinContainer.visibility = View.VISIBLE
        binding.layoutPatternContainer.visibility = View.GONE

        val pinLen = prefs.pinLength
        binding.dot4.visibility = if (pinLen >= 5) View.VISIBLE else View.GONE
        binding.dot5.visibility = if (pinLen >= 6) View.VISIBLE else View.GONE

        setupKeypadListeners()
    }

    private fun setupPatternLockView() {
        binding.layoutPinContainer.visibility = View.GONE
        binding.layoutPatternContainer.visibility = View.VISIBLE

        binding.patternLockView.setOnPatternListener { pattern ->
            if (prefs.verifyPattern(pattern)) {
                handleUnlockSuccess()
            } else {
                Toast.makeText(this, "Incorrect Pattern", Toast.LENGTH_SHORT).show()
                val shake = AnimationUtils.loadAnimation(this, R.anim.shake)
                binding.patternLockView.startAnimation(shake)
                Handler(Looper.getMainLooper()).postDelayed({
                    binding.patternLockView.clearPattern()
                }, 350)
            }
        }
    }

    private fun setupKeypadListeners() {
        val maxPinLen = prefs.pinLength
        val numberMap = mapOf(
            binding.key1 to "1", binding.key2 to "2", binding.key3 to "3",
            binding.key4 to "4", binding.key5 to "5", binding.key6 to "6",
            binding.key7 to "7", binding.key8 to "8", binding.key9 to "9",
            binding.key0 to "0"
        )

        numberMap.forEach { (view, digit) ->
            view.setOnClickListener {
                if (enteredPin.length < maxPinLen) {
                    enteredPin.append(digit)
                    updatePinDots()
                    if (enteredPin.length == maxPinLen) {
                        Handler(Looper.getMainLooper()).postDelayed({ verifyEnteredPin() }, 100)
                    }
                }
            }
        }

        binding.keyBackspace.setOnClickListener {
            if (enteredPin.isNotEmpty()) {
                enteredPin.deleteCharAt(enteredPin.length - 1)
                updatePinDots()
            }
        }

        binding.keyDone.setOnClickListener {
            verifyEnteredPin()
        }

        binding.btnCancelPin.setOnClickListener {
            goToHomeScreen()
        }

        binding.btnContinuePin.setOnClickListener {
            verifyEnteredPin()
        }
    }

    private fun updatePinDots() {
        val len = enteredPin.length
        binding.dot0.isSelected = len > 0
        binding.dot1.isSelected = len > 1
        binding.dot2.isSelected = len > 2
        binding.dot3.isSelected = len > 3
        binding.dot4.isSelected = len > 4
        binding.dot5.isSelected = len > 5
    }

    private fun verifyEnteredPin() {
        val pin = enteredPin.toString()
        if (prefs.verifyPin(pin)) {
            handleUnlockSuccess()
        } else {
            val shake = AnimationUtils.loadAnimation(this, R.anim.shake)
            binding.pinInputWrapper.startAnimation(shake)
            Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
            enteredPin.clear()
            updatePinDots()
        }
    }

    private fun setupBiometricPrompt() {
        executor = ContextCompat.getMainExecutor(this)
        biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    handleUnlockSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                }
            })

        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock $targetAppName")
            .setSubtitle("Confirm fingerprint to access $targetAppName")
            .setNegativeButtonText("Use " + prefs.lockType)
            .build()
    }

    private fun handleUnlockSuccess() {
        targetPackage?.let { pkg ->
            AppLockAccessibilityService.recordUnlock(pkg)
        }
        finish()
        overridePendingTransition(0, 0)
    }

    private fun goToHomeScreen() {
        AppLockAccessibilityService.isCurrentlyShowingOverlay = false
        val startMain = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(startMain)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goToHomeScreen()
    }
}
