package com.secure.applock.ui

import android.graphics.drawable.Drawable

data class AppItem(
    val name: String,
    val packageName: String,
    val icon: Drawable,
    var isLocked: Boolean
)
