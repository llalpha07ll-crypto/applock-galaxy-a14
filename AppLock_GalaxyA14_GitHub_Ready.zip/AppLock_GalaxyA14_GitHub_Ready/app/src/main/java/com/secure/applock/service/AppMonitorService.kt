package com.secure.applock.service

import android.app.Notification
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.secure.applock.AppLockApplication
import com.secure.applock.R
import com.secure.applock.data.AppLockPreferences
import com.secure.applock.ui.LockOverlayActivity

class AppMonitorService : Service() {

    private lateinit var prefs: AppLockPreferences
    private lateinit var usageStatsManager: UsageStatsManager
    private val handler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private var lastForegroundPackage: String? = null

    companion object {
        val unlockedAppsTimestamps = mutableMapOf<String, Long>()
        var isCurrentlyShowingOverlay = false

        fun recordUnlock(packageName: String) {
            unlockedAppsTimestamps[packageName] = SystemClock.elapsedRealtime()
            isCurrentlyShowingOverlay = false
        }

        fun lockAllImmediately() {
            unlockedAppsTimestamps.clear()
        }
    }

    private val systemEventsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // Instantly lock everything when phone screen turns off
                    unlockedAppsTimestamps.clear()
                    lastForegroundPackage = null
                }
                Intent.ACTION_CLOSE_SYSTEM_DIALOGS -> {
                    // Triggered when Home button or Recents button is tapped!
                    val reason = intent.getStringExtra("reason")
                    if (reason == "homekey" || reason == "recentapps") {
                        if (prefs.relockPolicy == "immediately") {
                            unlockedAppsTimestamps.clear()
                            lastForegroundPackage = null
                        }
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = AppLockPreferences(this)
        usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(systemEventsReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(systemEventsReceiver, filter)
        }

        startForeground(1001, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) {
            isRunning = true
            startMonitoringLoop()
        }
        return START_STICKY
    }

    private fun startMonitoringLoop() {
        handler.post(object : Runnable {
            override fun run() {
                checkForegroundApp()
                if (isRunning) {
                    // High-frequency polling (120ms) for ultra-fast response
                    handler.postDelayed(this, 120)
                }
            }
        })
    }

    private fun checkForegroundApp() {
        val currentPkg = getTopPackageName() ?: return

        // Skip our own overlay to prevent self-trigger loop
        if (currentPkg == packageName && isCurrentlyShowingOverlay) return

        if (currentPkg != lastForegroundPackage) {
            // App switched away!
            if (prefs.relockPolicy == "immediately") {
                // Instantly remove previous package from unlocked cache
                if (lastForegroundPackage != null && lastForegroundPackage != packageName) {
                    unlockedAppsTimestamps.remove(lastForegroundPackage)
                }
            }
            lastForegroundPackage = currentPkg
        }

        val isTargetLocked = if (currentPkg == packageName) {
            prefs.isSelfLockEnabled
        } else {
            prefs.isPackageLocked(currentPkg)
        }

        if (isTargetLocked) {
            if (!isAppTemporarilyUnlocked(currentPkg) && !isCurrentlyShowingOverlay) {
                triggerLockOverlay(currentPkg)
            }
        }
    }

    private fun isAppTemporarilyUnlocked(pkg: String): Boolean {
        val unlockTime = unlockedAppsTimestamps[pkg] ?: return false
        val elapsed = SystemClock.elapsedRealtime() - unlockTime

        return when (prefs.relockPolicy) {
            "immediately" -> false // Never keep unlocked if switched away or reopened
            "screen_off" -> true
            "1_min" -> elapsed < 60_000
            "5_min" -> elapsed < 300_000
            "custom" -> elapsed < (prefs.customTimeoutMinutes * 60_000L)
            else -> false
        }
    }

    private fun triggerLockOverlay(targetPackage: String) {
        isCurrentlyShowingOverlay = true
        val intent = Intent(this, LockOverlayActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            putExtra(LockOverlayActivity.EXTRA_TARGET_PACKAGE, targetPackage)
        }
        startActivity(intent)
    }

    private fun getTopPackageName(): String? {
        val endTime = System.currentTimeMillis()
        val beginTime = endTime - 1500
        val events = usageStatsManager.queryEvents(beginTime, endTime)
        val event = UsageEvents.Event()
        var lastPkg: String? = null

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED) {
                lastPkg = event.packageName
            }
        }
        return lastPkg
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, AppLockApplication.CHANNEL_ID)
            .setContentTitle("AppLock Pro Active")
            .setContentText("Monitoring applications in real-time")
            .setSmallIcon(R.drawable.ic_app_logo)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        try {
            unregisterReceiver(systemEventsReceiver)
        } catch (_: Exception) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
