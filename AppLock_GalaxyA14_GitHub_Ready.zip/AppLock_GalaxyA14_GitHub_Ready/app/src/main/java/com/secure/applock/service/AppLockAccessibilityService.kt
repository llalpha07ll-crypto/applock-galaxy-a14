package com.secure.applock.service

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import com.secure.applock.data.AppLockPreferences
import com.secure.applock.ui.LockOverlayActivity

class AppLockAccessibilityService : AccessibilityService() {

    private lateinit var prefs: AppLockPreferences
    private var lastForegroundPackage: String? = null

    companion object {
        val unlockedAppsTimestamps = mutableMapOf<String, Long>()
        var isCurrentlyShowingOverlay = false

        fun recordUnlock(packageName: String) {
            unlockedAppsTimestamps[packageName] = SystemClock.elapsedRealtime()
            isCurrentlyShowingOverlay = false
        }

        fun lockAllImmediately() {
            unlockedAppsTimestamps.clear()
        }
    }

    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                unlockedAppsTimestamps.clear()
                lastForegroundPackage = null
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = AppLockPreferences(this)
        val filter = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenOffReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(screenOffReceiver, filter)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val currentPkg = event.packageName?.toString() ?: return

        // Skip our own app overlay
        if (currentPkg == packageName) {
            return
        }

        if (currentPkg != lastForegroundPackage) {
            // App was switched away or closed
            if (prefs.relockPolicy == "immediately") {
                if (lastForegroundPackage != null && lastForegroundPackage != packageName) {
                    unlockedAppsTimestamps.remove(lastForegroundPackage)
                }
            }
            lastForegroundPackage = currentPkg
        }

        // Check if currentPkg is locked
        val isTargetLocked = prefs.isPackageLocked(currentPkg)
        if (isTargetLocked) {
            if (!isAppTemporarilyUnlocked(currentPkg) && !isCurrentlyShowingOverlay) {
                triggerLockOverlay(currentPkg)
            }
        }
    }

    private fun isAppTemporarilyUnlocked(pkg: String): Boolean {
        val unlockTime = unlockedAppsTimestamps[pkg] ?: return false
        val elapsed = SystemClock.elapsedRealtime() - unlockTime

        return when (prefs.relockPolicy) {
            "immediately" -> false
            "screen_off" -> true
            "1_min" -> elapsed < 60_000
            "5_min" -> elapsed < 300_000
            "custom" -> elapsed < (prefs.customTimeoutMinutes * 60_000L)
            else -> false
        }
    }

    private fun triggerLockOverlay(targetPackage: String) {
        isCurrentlyShowingOverlay = true
        val intent = Intent(this, LockOverlayActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            putExtra(LockOverlayActivity.EXTRA_TARGET_PACKAGE, targetPackage)
        }
        startActivity(intent)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(screenOffReceiver)
        } catch (_: Exception) {}
    }
}
