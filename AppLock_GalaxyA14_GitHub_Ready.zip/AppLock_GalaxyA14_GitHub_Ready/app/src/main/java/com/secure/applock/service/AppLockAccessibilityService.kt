package com.secure.applock.service

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import com.secure.applock.data.AppLockPreferences
import com.secure.applock.ui.LockOverlayActivity

class AppLockAccessibilityService : AccessibilityService() {

    private lateinit var prefs: AppLockPreferences
    
    companion object {
        // Currently active unlocked package while user is inside it
        var currentlyActiveUnlockedApp: String? = null
        var lastUnlockTimestamp: Long = 0L
        var isCurrentlyShowingOverlay = false

        fun recordUnlock(packageName: String) {
            currentlyActiveUnlockedApp = packageName
            lastUnlockTimestamp = SystemClock.elapsedRealtime()
            isCurrentlyShowingOverlay = false
        }

        fun lockAllImmediately() {
            currentlyActiveUnlockedApp = null
            lastUnlockTimestamp = 0L
            isCurrentlyShowingOverlay = false
        }
    }

    private val systemEventsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    // Instantly lock everything when phone screen turns off
                    lockAllImmediately()
                }
                Intent.ACTION_CLOSE_SYSTEM_DIALOGS -> {
                    // Triggered when Home button or Recent Apps button is pressed
                    val reason = intent.getStringExtra("reason")
                    if (reason == "homekey" || reason == "recentapps") {
                        if (prefs.relockPolicy == "immediately") {
                            lockAllImmediately()
                        }
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = AppLockPreferences(this)
        
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(systemEventsReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(systemEventsReceiver, filter)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val currentPkg = event.packageName?.toString() ?: return

        // Skip our own AppLock application
        if (currentPkg == packageName) return

        // Skip Android System UI navigation bar / status bar overlays
        if (currentPkg == "com.android.systemui") return

        // ========================================================
        // IMMEDIATELY RELOCK LOGIC:
        // If user left the currently unlocked app (e.g. went to launcher or another app)
        // ========================================================
        if (currentlyActiveUnlockedApp != null && currentPkg != currentlyActiveUnlockedApp) {
            if (prefs.relockPolicy == "immediately") {
                // Instantly wipe unlocked status the very millisecond they leave!
                currentlyActiveUnlockedApp = null
                lastUnlockTimestamp = 0L
            }
        }

        // Check if the current foreground app is on the lock list
        val isTargetLocked = prefs.isPackageLocked(currentPkg)
        if (isTargetLocked) {
            val isUnlocked = isAppTemporarilyUnlocked(currentPkg)
            if (!isUnlocked && !isCurrentlyShowingOverlay) {
                triggerLockOverlay(currentPkg)
            }
        }
    }

    private fun isAppTemporarilyUnlocked(pkg: String): Boolean {
        // If policy is "immediately", it is ONLY unlocked while user remains inside that exact app
        if (prefs.relockPolicy == "immediately") {
            return pkg == currentlyActiveUnlockedApp
        }

        if (pkg != currentlyActiveUnlockedApp) return false

        val elapsed = SystemClock.elapsedRealtime() - lastUnlockTimestamp
        return when (prefs.relockPolicy) {
            "screen_off" -> true // Stays unlocked until screen off receiver triggers
            "1_min" -> elapsed < 60_000
            "5_min" -> elapsed < 300_000
            "custom" -> elapsed < (prefs.customTimeoutMinutes * 60_000L)
            else -> false
        }
    }

    private fun triggerLockOverlay(targetPackage: String) {
        isCurrentlyShowingOverlay = true
        val intent = Intent(this, LockOverlayActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NO_ANIMATION
            putExtra(LockOverlayActivity.EXTRA_TARGET_PACKAGE, targetPackage)
        }
        startActivity(intent)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(systemEventsReceiver)
        } catch (_: Exception) {}
    }
}
