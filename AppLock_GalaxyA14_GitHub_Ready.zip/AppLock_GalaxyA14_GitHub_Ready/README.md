# AppLock Pro - Samsung Galaxy A14 5G (One UI Edition)

[![Android CI](https://github.com/placeholder/applock-galaxy-a14/actions/workflows/build_apk.yml/badge.svg)](https://github.com)
[![Platform](https://img.shields.io/badge/Platform-Android%2014%20(One%20UI%20Core)-blue.svg)](https://developer.android.com)
[![Language](https://img.shields.io/badge/Language-Kotlin-purple.svg)](https://kotlinlang.org)
[![Security](https://img.shields.io/badge/Security-AES--256%20Encrypted-green.svg)](https://developer.android.com/reference/androidx/security/crypto/EncryptedSharedPreferences)

A modern, highly secure Android AppLock designed specifically to match the native **Samsung One UI** design of the **Samsung Galaxy A14 5G**, coupled with an **iOS-inspired Liquid Glass (Frosted Glassmorphism)** in-app management interface.

---

## Key Features

1. **Native Samsung One UI Lock Screen:**
   - Dynamically detects the target app (e.g. WhatsApp, Instagram, Arattai, Gallery) and displays the authentic target app name and icon.
   - Screen 1: Biometric fingerprint circle prompt matching Samsung One UI dialogs (`Confirm biometric authentication to access <App>`).
   - Screen 2: Authentic One UI 3x4 numeric keypad (digits 1–9 with ABC/DEF subtext, Backspace, 0, and Done button).

2. **iOS-Style Liquid Glass In-App Dashboard:**
   - Frosted translucent glassmorphism cards with subtle border highlights and neon accents.
   - Real-time search bar to quickly filter installed applications.
   - One-tap **"Lock All / Unlock All"** master toggle with live locked app counters.

3. **Custom Relock Timeout:**
   - **Immediately:** Relocks instantly whenever you switch away or minimize the app.
   - **When Screen Turns Off:** Stays unlocked while you use your phone; relocks only when phone goes to sleep.
   - **Custom Timer:** 1 min, 5 min, or custom duration.

4. **Independent Custom Master PIN:**
   - Operates with an independent 4-digit Master PIN stored securely in Android `EncryptedSharedPreferences` with SHA-256 + Salt hashing.
   - Completely separate from your Samsung device lockscreen PIN.
   - **Biometric Control:** Toggle Biometrics ON/OFF. When disabled, apps can only be opened with your private AppLock PIN.

5. **Self-Lock Protection:**
   - AppLock Pro itself is protected by the Master PIN.

6. **Clean Play Protect Installation:**
   - Fully configured for Android 14 (API 34) with v1, v2, and v3 APK signing schemes to install cleanly without "Blocked by Play Protect" warnings.

7. **3-Tab Bottom Navigation Bar:**
   - **Management:** Search apps, toggle locks, view stats.
   - **Security:** Configure relock timeout, self-lock, and biometric toggles.
   - **Settings:** Change Master PIN and inspect system permissions.

---

## Project Structure

```text
applock-galaxy-a14/
├── .github/
│   └── workflows/
│       └── build_apk.yml             # Automatic GitHub Actions CI/CD to build APK
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml       # Permissions (UsageStats, Overlay, ForegroundService)
│   │   ├── java/com/secure/applock/
│   │   │   ├── AppLockApplication.kt # Service Notification Channel setup
│   │   │   ├── data/
│   │   │   │   └── AppLockPreferences.kt # EncryptedSharedPreferences (AES-256)
│   │   │   ├── receiver/
│   │   │   │   └── BootReceiver.kt   # Persistent background protection on restart
│   │   │   ├── service/
│   │   │   │   └── AppMonitorService.kt # Real-time foreground app monitoring & timeout
│   │   │   └── ui/
│   │   │       ├── AppItem.kt
│   │   │       ├── AppListAdapter.kt # Glassmorphic list view
│   │   │       ├── LockOverlayActivity.kt # Samsung One UI lock card
│   │   │       └── MainActivity.kt   # 3-Tab Liquid Glass UI
│   │   └── res/
│   │       ├── layout/
│   │       │   ├── activity_lock_overlay.xml # One UI Keypad & Biometric screen
│   │       │   ├── activity_main.xml         # Liquid glass dashboard
│   │       │   └── item_app_glass.xml        # Translucent app card
│   │       └── drawable/                     # Keypad tiles, vector icons, glass backgrounds
├── build.gradle.kts
├── settings.gradle.kts
└── PLAY_PROTECT_CLEAN_INSTALL_GUIDE.md
```

---

## How to Push This Repository to GitHub

### Method A: Using Terminal / Git Commands

1. Create a new repository on [GitHub](https://github.com/new) named `applock-galaxy-a14` (Keep it Public or Private, do not initialize with README since this project already has one).
2. Open terminal in the project folder and run:

```bash
# 1. Initialize git (if not already done)
git init -b main

# 2. Add all files and commit
git add .
git commit -m "Initial commit: Samsung Galaxy A14 One UI AppLock with Liquid Glass UI"

# 3. Link your remote GitHub repository
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/applock-galaxy-a14.git

# 4. Push code to GitHub
git push -u origin main
```

### Method B: Using GitHub Desktop or GitHub Web Upload
1. If using **GitHub Web**: On GitHub, create a repository, click **Upload files**, drag and drop all extracted project files, and click **Commit changes**.
2. If using **GitHub Desktop**: Click **File > Add Local Repository**, select this folder, and click **Publish repository**.

---

## Automated APK Download via GitHub Actions

This repository includes a ready-to-use GitHub Actions workflow (`.github/workflows/build_apk.yml`).
- Whenever you push code to GitHub, GitHub's cloud servers will automatically compile the code and build the APK!
- You can download the compiled APK directly from the **Actions** tab on your GitHub repository page without needing Android Studio installed on your computer.

---

## Required Permissions on Galaxy A14 5G

When launching the app for the first time:
1. **Usage Access:** `Settings > Apps > Special app access > Usage access` (Allows AppLock to detect when a locked app opens).
2. **Appear on Top:** `Settings > Apps > Special app access > Appear on top` (Displays the One UI lock popup overlay).

---

## License
MIT License - Open Source & Free to use.
