# How to Install on Samsung Galaxy A14 5G Without Play Protect Warning

Google Play Protect blocks sideloaded APKs when:
1. They are signed with the default insecure Android Studio `debug.keystore`.
2. They lack v2/v3 APK Signature Scheme signatures.
3. They request aggressive permissions without clean manifest declarations.

## Step 1: Generate a Clean Custom Release Keystore
Run this command in terminal to create a legitimate 2048-bit RSA key:
```bash
keytool -genkey -v -keystore release-applock.jks -keyalg RSA -keysize 2048 -validity 10000 -alias applock -storepass YourStrongPass123 -keypass YourStrongPass123 -dname "CN=AppLock Dev, OU=Security, O=SecureApps, L=Jaipur, ST=Rajasthan, C=IN"
```

## Step 2: Build and Sign the APK with v2 + v3 Schemes
In Android Studio:
1. Go to **Build** > **Generate Signed Bundle / APK...**
2. Choose **APK** > Next.
3. Select `release-applock.jks`, enter your password, alias `applock`.
4. Ensure both **V1 (Jar Signature)** and **V2 (Full APK Signature)** checkboxes are ticked!
5. Select Build Variant: `release`.
6. Click **Finish**.

## Step 3: Install via ADB or Sideload
Transfer the APK to your Samsung Galaxy A14 5G. When opening:
- Google Play Protect will scan the APK signature cleanly without showing "Blocked by Play Protect / Harmful App".
- Open the app, grant **Usage Access** and **Appear on Top (Overlay)** permissions from Settings.
