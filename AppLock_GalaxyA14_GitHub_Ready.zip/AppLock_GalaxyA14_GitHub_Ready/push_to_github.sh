#!/bin/bash
echo "=================================================="
echo "    AppLock Pro - GitHub Push Helper Script       "
echo "=================================================="
echo ""

if [ ! -d ".git" ]; then
    git init -b main
    echo "[✓] Initialized Git repository on 'main' branch."
fi

git add .
git commit -m "Samsung Galaxy A14 One UI AppLock Pro with Liquid Glass UI" || true

echo ""
echo "Please enter your GitHub Repository URL:"
echo "Example: https://github.com/your-username/applock-galaxy-a14.git"
read -p "Repo URL: " REPO_URL

if [ -n "$REPO_URL" ]; then
    git remote remove origin 2>/dev/null || true
    git remote add origin "$REPO_URL"
    echo "[✓] Remote origin set to $REPO_URL"
    echo "[*] Pushing to GitHub..."
    git push -u origin main
    echo "[✓] Successfully pushed to GitHub!"
else
    echo "[!] No URL provided. You can push manually using:"
    echo "    git remote add origin <URL>"
    echo "    git push -u origin main"
fi
