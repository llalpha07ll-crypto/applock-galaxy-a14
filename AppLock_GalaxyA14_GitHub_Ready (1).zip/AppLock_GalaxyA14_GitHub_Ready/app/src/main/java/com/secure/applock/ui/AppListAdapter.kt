package com.secure.applock.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.secure.applock.databinding.ItemAppSamsungBinding

class AppListAdapter(
    private val onToggleLock: (AppItem, Boolean) -> Unit
) : RecyclerView.Adapter<AppListAdapter.AppViewHolder>() {

    private var items = listOf<AppItem>()

    fun submitList(newItems: List<AppItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val binding = ItemAppSamsungBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class AppViewHolder(private val binding: ItemAppSamsungBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(app: AppItem) {
            binding.ivAppIcon.setImageDrawable(app.icon)
            binding.tvAppName.text = app.name
            binding.tvPackageName.text = app.packageName
            
            binding.switchLock.setOnCheckedChangeListener(null)
            binding.switchLock.isChecked = app.isLocked
            binding.switchLock.setOnCheckedChangeListener { _, isChecked ->
                app.isLocked = isChecked
                onToggleLock(app, isChecked)
            }
        }
    }
}
