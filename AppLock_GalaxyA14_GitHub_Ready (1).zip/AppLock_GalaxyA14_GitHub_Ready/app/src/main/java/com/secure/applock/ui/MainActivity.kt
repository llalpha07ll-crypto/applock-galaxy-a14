package com.secure.applock.ui

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.textfield.TextInputEditText
import com.secure.applock.R
import com.secure.applock.data.AppLockPreferences
import com.secure.applock.databinding.ActivityMainBinding
import com.secure.applock.service.AppLockAccessibilityService
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefs: AppLockPreferences
    private lateinit var adapter: AppListAdapter
    private val allApps = mutableListOf<AppItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = AppLockPreferences(this)

        applySelectedTheme(prefs.appTheme)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!prefs.isMasterPinSet() && !prefs.isMasterPatternSet()) {
            showInitialPinSetupDialog()
        }

        checkAndRequestPermissions()
        setupUI()
        setupBottomNavigation()
        loadInstalledApps()
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityStatus()
    }

    private fun updateAccessibilityStatus() {
        val isEnabled = isAccessibilityServiceEnabled()
        if (!isEnabled) {
            binding.tvAppTitle.text = "AppLock (Tap to Enable)"
            binding.tvAppTitle.setOnClickListener {
                promptEnableAccessibility()
            }
        } else {
            binding.tvAppTitle.text = "AppLock"
            binding.tvAppTitle.setOnClickListener(null)
        }
    }

    private fun applySelectedTheme(theme: String) {
        when (theme) {
            "LIGHT" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "DARK" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            else -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    private fun setupUI() {
        adapter = AppListAdapter { app, isLocked ->
            prefs.toggleAppLock(app.packageName, isLocked)
            updateLockCounts()
        }
        binding.rvApps.layoutManager = LinearLayoutManager(this)
        binding.rvApps.adapter = adapter

        binding.etSearchApps.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterApps(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        binding.btnLockAll.setOnClickListener {
            val allLocked = allApps.all { it.isLocked }
            val newState = !allLocked
            allApps.forEach {
                it.isLocked = newState
                prefs.toggleAppLock(it.packageName, newState)
            }
            adapter.submitList(allApps.toList())
            updateLockCounts()
            Toast.makeText(this, if (newState) "All apps locked" else "All apps unlocked", Toast.LENGTH_SHORT).show()
        }

        setupSecurityTab()
        setupSettingsTab()
    }

    private fun setupSecurityTab() {
        val policies = listOf("immediately", "screen_off", "1_min", "5_min", "custom")
        val displayPolicies = listOf("Immediately (Lock on Exit)", "When Screen Turns Off", "After 1 Minute", "After 5 Minutes", "Custom (15 min)")
        
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, displayPolicies)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerRelockPolicy.adapter = spinnerAdapter
        
        val currentIndex = policies.indexOf(prefs.relockPolicy).coerceAtLeast(0)
        binding.spinnerRelockPolicy.setSelection(currentIndex)

        binding.switchSelfLock.isChecked = prefs.isSelfLockEnabled
        binding.switchSelfLock.setOnCheckedChangeListener { _, isChecked ->
            prefs.isSelfLockEnabled = isChecked
        }

        binding.switchBiometric.isChecked = prefs.isBiometricEnabled
        binding.switchBiometric.setOnCheckedChangeListener { _, isChecked ->
            prefs.isBiometricEnabled = isChecked
        }
    }

    private fun setupSettingsTab() {
        binding.switchDarkTheme.isChecked = prefs.appTheme == "DARK"
        binding.switchDarkTheme.setOnCheckedChangeListener { _, isChecked ->
            val newTheme = if (isChecked) "DARK" else "LIGHT"
            prefs.appTheme = newTheme
            applySelectedTheme(newTheme)
            recreate()
        }

        binding.radioLockPin.isChecked = prefs.lockType == "PIN"
        binding.radioLockPattern.isChecked = prefs.lockType == "PATTERN"

        binding.radioGroupLockType.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.radioLockPattern) {
                prefs.lockType = "PATTERN"
                showSetPatternDialog()
            } else {
                prefs.lockType = "PIN"
                Toast.makeText(this, "Lock Type set to PIN", Toast.LENGTH_SHORT).show()
            }
        }

        binding.spinnerPinLength.setSelection(if (prefs.pinLength == 6) 1 else 0)

        binding.btnChangePin.setOnClickListener {
            showChangePinDialog()
        }
    }

    private fun setupBottomNavigation() {
        binding.bottomNavBar.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_management -> {
                    binding.layoutManagementTab.visibility = View.VISIBLE
                    binding.layoutSecurityTab.visibility = View.GONE
                    binding.layoutSettingsTab.visibility = View.GONE
                    true
                }
                R.id.nav_security -> {
                    binding.layoutManagementTab.visibility = View.GONE
                    binding.layoutSecurityTab.visibility = View.VISIBLE
                    binding.layoutSettingsTab.visibility = View.GONE
                    true
                }
                R.id.nav_settings -> {
                    binding.layoutManagementTab.visibility = View.GONE
                    binding.layoutSecurityTab.visibility = View.GONE
                    binding.layoutSettingsTab.visibility = View.VISIBLE
                    true
                }
                else -> false
            }
        }
    }

    private fun loadInstalledApps() {
        val pm = packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        allApps.clear()

        val lockedSet = prefs.getLockedPackages()

        for (app in packages) {
            val launchIntent = pm.getLaunchIntentForPackage(app.packageName)
            // SHOW APPLOCK PRO ITSELF IN THE LIST TOO (per user request)
            if (launchIntent != null || app.packageName == packageName) {
                val name = pm.getApplicationLabel(app).toString()
                val icon = pm.getApplicationIcon(app)
                val isLocked = lockedSet.contains(app.packageName)
                allApps.add(AppItem(name, app.packageName, icon, isLocked))
            }
        }

        allApps.sortBy { it.name.lowercase(Locale.ROOT) }
        adapter.submitList(allApps.toList())
        updateLockCounts()
    }

    private fun filterApps(query: String) {
        val filtered = allApps.filter {
            it.name.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true)
        }
        adapter.submitList(filtered)
    }

    private fun updateLockCounts() {
        val lockedCount = allApps.count { it.isLocked }
        binding.tvLockedCount.text = lockedCount.toString()
        binding.tvUnlockedCount.text = (allApps.size - lockedCount).toString()
        binding.btnLockAll.text = if (lockedCount == allApps.size) "Unlock All" else "Lock All"
    }

    private fun showInitialPinSetupDialog() {
        val input = TextInputEditText(this)
        input.hint = "4 or 6-digit PIN"
        AlertDialog.Builder(this)
            .setTitle("Create Master PIN")
            .setMessage("Set your private AppLock PIN.")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Set PIN") { _, _ ->
                val pin = input.text.toString().trim()
                if ((pin.length == 4 || pin.length == 6) && pin.all { it.isDigit() }) {
                    prefs.pinLength = pin.length
                    prefs.setMasterPin(pin)
                    Toast.makeText(this, "Master PIN created successfully", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Please enter 4 or 6 digits", Toast.LENGTH_SHORT).show()
                    showInitialPinSetupDialog()
                }
            }
            .show()
    }

    private fun showChangePinDialog() {
        val input = TextInputEditText(this)
        input.hint = "New PIN (4 or 6 digits)"
        AlertDialog.Builder(this)
            .setTitle("Change Master PIN")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val pin = input.text.toString().trim()
                if ((pin.length == 4 || pin.length == 6) && pin.all { it.isDigit() }) {
                    prefs.pinLength = pin.length
                    prefs.setMasterPin(pin)
                    Toast.makeText(this, "PIN updated successfully (${pin.length}-digits)", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "PIN must be 4 or 6 digits", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSetPatternDialog() {
        val patternView = PatternLockView(this)
        val dialog = AlertDialog.Builder(this)
            .setTitle("Draw New Pattern")
            .setMessage("Connect at least 4 dots to set your master pattern")
            .setView(patternView)
            .setNegativeButton("Cancel", null)
            .create()

        patternView.setOnPatternListener { pattern ->
            if (pattern.split("-").size >= 4) {
                prefs.setMasterPattern(pattern)
                Toast.makeText(this, "Master Pattern saved successfully", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Connect at least 4 dots", Toast.LENGTH_SHORT).show()
                patternView.clearPattern()
            }
        }
        dialog.show()
    }

    private fun checkAndRequestPermissions() {
        if (!isAccessibilityServiceEnabled()) {
            promptEnableAccessibility()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant Appear on Top permission", Toast.LENGTH_LONG).show()
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            startActivity(intent)
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        for (service in enabledServices) {
            if (service.id.contains(packageName)) {
                return true
            }
        }
        return false
    }

    private fun promptEnableAccessibility() {
        AlertDialog.Builder(this)
            .setTitle("Enable AppLock Service")
            .setMessage("Enable AppLock Pro in Accessibility settings to protect your applications.")
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Later", null)
            .show()
    }
}
